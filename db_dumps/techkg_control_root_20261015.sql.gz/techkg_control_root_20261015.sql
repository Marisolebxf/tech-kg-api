-- MySQL dump 10.13  Distrib 8.4.10, for Linux (x86_64)
--
-- Host: localhost    Database: techkg_control
-- ------------------------------------------------------
-- Server version	8.4.10

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `techkg_control`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `techkg_control` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

USE `techkg_control`;

--
-- Table structure for table `batches`
--

DROP TABLE IF EXISTS `batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `update_date` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_batches_update_date` (`update_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batches`
--

LOCK TABLES `batches` WRITE;
/*!40000 ALTER TABLE `batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kg_schema_definition`
--

DROP TABLE IF EXISTS `kg_schema_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kg_schema_definition` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `schema_key` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `graph_space` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kind` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'entity/relation',
  `name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `identity_key` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_identity_key` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  `attribute_source` varchar(1024) COLLATE utf8mb4_unicode_ci NOT NULL,
  `instance_count` bigint NOT NULL,
  `version` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_order` int NOT NULL,
  `is_core` tinyint(1) NOT NULL,
  `relation_category` varchar(16) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'fact/inferred，仅关系 Schema 使用',
  `is_system` tinyint(1) NOT NULL,
  `created_by` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_schema_id` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_schema_id` varchar(36) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_expression` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target_expression` varchar(512) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `llm_config_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '作业默认 LLM 配置 ID（软关联 platform_llm_config.id）',
  `ddl_statement` varchar(2048) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ddl_status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'pending/succeeded/failed/skipped',
  `ddl_error` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ddl_executed_at` datetime DEFAULT NULL,
  `property_revision` int NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  `updated_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_kg_schema_definition_key` (`schema_key`,`graph_space`),
  UNIQUE KEY `uk_kg_schema_definition_name` (`name`,`graph_space`),
  KEY `source_schema_id` (`source_schema_id`),
  KEY `target_schema_id` (`target_schema_id`),
  KEY `idx_kg_schema_definition_kind_created` (`kind`,`created_at`),
  KEY `idx_kg_schema_definition_space` (`graph_space`),
  CONSTRAINT `kg_schema_definition_ibfk_1` FOREIGN KEY (`source_schema_id`) REFERENCES `kg_schema_definition` (`id`) ON DELETE RESTRICT,
  CONSTRAINT `kg_schema_definition_ibfk_2` FOREIGN KEY (`target_schema_id`) REFERENCES `kg_schema_definition` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='知识图谱实体与关系 Schema 定义';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kg_schema_definition`
--

LOCK TABLES `kg_schema_definition` WRITE;
/*!40000 ALTER TABLE `kg_schema_definition` DISABLE KEYS */;
INSERT INTO `kg_schema_definition` VALUES ('0045f86f-6b91-5c17-8c8b-fd129b4737d6','has-product','dev','relation','HAS_PRODUCT','企业拥有产品','产品拆分、标准化后生成','','','',0,'v1.8',12,0,'fact',1,NULL,'ffe23d4b-7198-523a-b436-cacb0dde45ff','384239f4-0792-5f53-836b-42352b38e7e2','Organization','Product',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('0085cb12-f8da-558c-929f-f4a28b678a34','participate-in','dev','relation','PARTICIPATE_IN','参与项目','参与者拆分对齐后生成','','','',0,'v1.8',15,0,'fact',1,NULL,NULL,'51414fdf-6327-5724-b694-adb492403cc4','Expert / Person','Project',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('02603b0f-a422-5fd0-8d3a-53be348e57ec','paper','dev','entity','Paper','论文','论文成果与引用信息','DOI / paper_id','paper_id','dwd_zh_paper_detail / dwd_en_paper_detail',0,'v1.8',2,1,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('07787f00-01f2-581b-9edb-a46fe87c753b','project-output-paper','dev','relation','PROJECT_OUTPUT_PAPER','项目产出论文','DOI 或 paper_id 对齐','','','',0,'v1.8',19,0,'fact',1,NULL,'51414fdf-6327-5724-b694-adb492403cc4','02603b0f-a422-5fd0-8d3a-53be348e57ec','Project','Paper',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('097d97e5-1c41-5d05-b91e-f965814fc69f','study-at','dev','relation','STUDY_AT','就读','教育背景抽取学校、专业、学历和时间','','','',0,'v1.8',3,0,'fact',1,NULL,NULL,'ffe23d4b-7198-523a-b436-cacb0dde45ff','Expert / Person','Organization',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('09854c48-54fa-5ee7-9b90-4a70d13bf0b4','report-org','dev','relation','REPORT_ORG','报告机构','完成单位对齐后生成','','','',0,'v1.8',28,0,'fact',1,NULL,'2c0881ca-0e78-541a-9415-23d4967f1ca5','ffe23d4b-7198-523a-b436-cacb0dde45ff','Report','Organization',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('09be6ac2-e279-553a-a397-85ecbb7461b6','own-patent','dev','relation','OWN_PATENT','拥有专利','当前权利人对齐后生成','','','',0,'v1.8',24,0,'fact',1,NULL,NULL,'93c39017-e78f-5e75-b87f-98be59a43e12','Organization / Person','Patent',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('0b489152-3622-5fc2-9682-3704a8bd8d5b','belongs-to-chain-node','dev','relation','BELONGS_TO_CHAIN_NODE','企业属于产业链节点','企业对齐后保留 chain_score','','','',0,'v1.8',38,0,'fact',1,NULL,'ffe23d4b-7198-523a-b436-cacb0dde45ff','e4f64b75-427f-5af5-8fa3-685dfcce1d11','Organization','IndustryChainNode',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('0be976a5-5517-58dd-8155-ec80e942c308','paper-field','dev','relation','PAPER_FIELD','论文研究方向','关键词与学科分类归一','','','',0,'v1.8',8,0,'fact',1,NULL,'02603b0f-a422-5fd0-8d3a-53be348e57ec','dbaa2a42-66f7-5061-8175-c675ed08212b','Paper','ResearchField',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('0ef6cd3b-ff8d-5c97-9b1f-5c26f81abfb9','indirect-relation','dev','relation','INDIRECT_RELATION','专家间接关系','基于标准事实关系做多跳路径分析','','','',0,'v1.8',4,0,'inferred',1,NULL,'283aaf94-07a4-5bdb-af0a-d521b703790b',NULL,'Expert','其他实体',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('11373021-4da5-5c58-a0a0-92d68cce22e3','chain-overview-relation','dev','relation','CHAIN_OVERVIEW_RELATION','产业链全景关联','节点、企业、产品、专家、政策和事件综合关联','','','',0,'v1.8',8,0,'inferred',1,NULL,'e4f64b75-427f-5af5-8fa3-685dfcce1d11',NULL,'IndustryChainNode','多类实体',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('172c11d4-9a47-5467-843b-7830a09bd5b1','expert-company-relation','dev','relation','EXPERT_COMPANY_RELATION','专家企业关系','任职、专利、项目、高管与产品领域综合判定','','','',0,'v1.8',6,0,'inferred',1,NULL,'283aaf94-07a4-5bdb-af0a-d521b703790b','ffe23d4b-7198-523a-b436-cacb0dde45ff','Expert','Organization',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('18cf138f-b599-52e3-9295-4f2264c6cc99','executive-of','dev','relation','EXECUTIVE_OF','高管任职','高管姓名、职务和机构对齐','','','',0,'v1.8',11,0,'fact',1,NULL,NULL,'ffe23d4b-7198-523a-b436-cacb0dde45ff','Expert / Person','Organization',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('1a76477d-c011-5c01-a24d-5ed21bb7fc6d','related-event','dev','relation','RELATED_EVENT','产业链节点关联事件','产业链资讯生成事件','','','',0,'v1.8',40,0,'fact',1,NULL,'e4f64b75-427f-5af5-8fa3-685dfcce1d11','67702440-021d-5db9-8a73-e13a5c11ce4f','IndustryChainNode','Event',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('1c33af51-947b-5c65-a242-b67c82a85781','shareholder-of','dev','relation','SHAREHOLDER_OF','股东关系','股东名称对齐，保留持股比例','','','',0,'v1.8',9,0,'fact',1,NULL,NULL,'ffe23d4b-7198-523a-b436-cacb0dde45ff','Organization / Person','Organization',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('231790be-b6dd-5d80-affc-c262840d2a68','patent-field','dev','relation','PATENT_FIELD','专利技术方向','IPC / IPCR / CPC 分类标准化','','','',0,'v1.8',25,0,'fact',1,NULL,'93c39017-e78f-5e75-b87f-98be59a43e12','dbaa2a42-66f7-5061-8175-c675ed08212b','Patent','ResearchField',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('283aaf94-07a4-5bdb-af0a-d521b703790b','expert','dev','entity','Expert','专家 / 人才 / 学者','统一承载科研与产业人才主体','scholar_id / expert_id','expert_id','dwd_scholar',0,'v1.8',0,1,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('28cbffc8-8f01-5c28-82d8-23b2a816c538','r-e-f-e-r-e-n-c-e-s','dev','relation','REFERENCES','论文参考','参考文献对齐后生成','','','',0,'v1.8',7,0,'fact',1,NULL,'02603b0f-a422-5fd0-8d3a-53be348e57ec','02603b0f-a422-5fd0-8d3a-53be348e57ec','Paper','Paper',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('2924fc2d-afae-5a53-91f2-da22af424c8b','project-output-patent','dev','relation','PROJECT_OUTPUT_PATENT','项目产出专利','专利号或 patent_id 对齐','','','',0,'v1.8',20,0,'fact',1,NULL,'51414fdf-6327-5724-b694-adb492403cc4','93c39017-e78f-5e75-b87f-98be59a43e12','Project','Patent',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('2c0881ca-0e78-541a-9415-23d4967f1ca5','report','dev','entity','Report','报告','科技报告及其作者、机构、论文和项目关联','report_id','report_id','dwd_zh_report / dwd_en_report',0,'v1.8',5,1,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('30ddf80e-08ab-52ee-a874-ee16bcd76ac7','project-field','dev','relation','PROJECT_FIELD','项目研究方向','学科代码优先，关键词辅助','','','',0,'v1.8',18,0,'fact',1,NULL,'51414fdf-6327-5724-b694-adb492403cc4','dbaa2a42-66f7-5061-8175-c675ed08212b','Project','ResearchField',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('3256818a-fcb8-54d2-8524-81b3e07f1806','org-field','dev','relation','ORG_FIELD','企业技术领域','行业分类、经营范围和产品领域归一','','','',0,'v1.8',41,0,'fact',1,NULL,'ffe23d4b-7198-523a-b436-cacb0dde45ff','dbaa2a42-66f7-5061-8175-c675ed08212b','Organization','ResearchField',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('381db037-df95-5c9a-82c4-310da83fa9c2','has-research-field','dev','relation','HAS_RESEARCH_FIELD','专家研究方向','专家方向拆分、标准化','','','',0,'v1.8',0,0,'fact',1,NULL,'283aaf94-07a4-5bdb-af0a-d521b703790b','dbaa2a42-66f7-5061-8175-c675ed08212b','Expert','ResearchField',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('384239f4-0792-5f53-836b-42352b38e7e2','product','dev','entity','Product','产品 / 技术产品','企业产品、技术产品与产业链节点','产品 ID / 标准产品名','product_id / 标准名','dwd_org_industry_chain_prod_dtl',0,'v1.8',9,1,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('42931488-6ba7-52d5-940d-c0a9b94904f0','cooperative-output','dev','relation','COOPERATIVE_OUTPUT','合作成果','共同论文、专利、项目和报告统计','','','',0,'v1.8',5,0,'inferred',1,NULL,'283aaf94-07a4-5bdb-af0a-d521b703790b',NULL,'Expert','Achievement 视图',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('51414fdf-6327-5724-b694-adb492403cc4','project','dev','entity','Project','项目','科研项目、资助、参与人员与项目成果','id / project_number','project_id','dwd_zh_project / dwd_en_project',0,'v1.8',3,1,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('51e13a94-f251-5c1f-8e9d-57a01cd7a920','apply-patent','dev','relation','APPLY_PATENT','申请专利','申请人对齐后生成','','','',0,'v1.8',23,0,'fact',1,NULL,NULL,'93c39017-e78f-5e75-b87f-98be59a43e12','Organization / Person','Patent',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('532cc2ea-eecb-518b-99c8-88edc240e390','p-u-b-l-i-s-h','dev','relation','PUBLISH','发表论文','作者对齐后生成，保留作者顺序','','','',0,'v1.8',1,0,'fact',1,NULL,'283aaf94-07a4-5bdb-af0a-d521b703790b','02603b0f-a422-5fd0-8d3a-53be348e57ec','Expert','Paper',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('5390a50c-76dc-5c73-9539-7dd545ffa68d','project-output-report','dev','relation','PROJECT_OUTPUT_REPORT','项目产出报告','报告对齐后生成','','','',0,'v1.8',21,0,'fact',1,NULL,'51414fdf-6327-5724-b694-adb492403cc4','2c0881ca-0e78-541a-9415-23d4967f1ca5','Project','Report',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('59cb4b88-ee38-5e0d-b72d-158a543e5d28','parent-of','dev','relation','PARENT_OF','产业链父子节点','parent_id 指向 node_id','','','',0,'v1.8',36,0,'fact',1,NULL,'e4f64b75-427f-5af5-8fa3-685dfcce1d11','e4f64b75-427f-5af5-8fa3-685dfcce1d11','IndustryChainNode','IndustryChainNode',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('601f5f43-0da8-57d0-9009-eccbe3fb5ad0','has-chain-node','dev','relation','HAS_CHAIN_NODE','产业链包含节点','chain_code + node_id','','','',0,'v1.8',35,0,'fact',1,NULL,'cdac3e3e-22d1-5e63-86d4-52e8baa67523','e4f64b75-427f-5af5-8fa3-685dfcce1d11','IndustryChain','IndustryChainNode',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('617e742a-bb5d-5d10-bd20-66a4692e7c91','has-event','dev','relation','HAS_EVENT','主体发生事件','企业与资讯、融资、并购等事件连接','','','',0,'v1.8',13,0,'fact',1,NULL,'ffe23d4b-7198-523a-b436-cacb0dde45ff','67702440-021d-5db9-8a73-e13a5c11ce4f','Organization','Event',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('62300f5f-af9b-543f-8dac-aac0aee5e80e','policy','dev','entity','Policy','政策','政策文本、发布部门、领域与产业链节点','id / recordId / URL','policy_id','dws_zck_policy / dwd_zck_intl_policy',0,'v1.8',6,1,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('67702440-021d-5db9-8a73-e13a5c11ce4f','event','dev','entity','Event','事件 / 资讯','用 event_type 区分资讯、融资、投资、并购、政策等事件','news_id / URL / 生成 ID','event_id','dwd_industry_chain_news_info / dwd_org_important_news_info',0,'v1.8',7,1,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('6d74ae2d-6838-5493-84c2-5c81382adc14','policy-related-field','dev','relation','POLICY_RELATED_FIELD','政策关联领域','关键词、全要素和正文抽取','','','',0,'v1.8',32,0,'fact',1,NULL,'62300f5f-af9b-543f-8dac-aac0aee5e80e','dbaa2a42-66f7-5061-8175-c675ed08212b','Policy','ResearchField',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('6dc80b11-5fc1-560e-8821-71918d65ed41','policy-related-chain-node','dev','relation','POLICY_RELATED_CHAIN_NODE','政策关联产业链节点','关键词与语义匹配','','','',0,'v1.8',33,0,'fact',1,NULL,'62300f5f-af9b-543f-8dac-aac0aee5e80e','e4f64b75-427f-5af5-8fa3-685dfcce1d11','Policy','IndustryChainNode',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('73458f60-7701-5d45-afd9-7adb82c615fb','invent-patent','dev','relation','INVENT_PATENT','发明专利','发明人对齐后生成','','','',0,'v1.8',22,0,'fact',1,NULL,NULL,'93c39017-e78f-5e75-b87f-98be59a43e12','Expert / Person','Patent',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('74e42d05-d3a0-53f9-8737-c9f4cb0abeba','c-o-l-l-e-a-g-u-e','dev','relation','COLLEAGUE','同事关系','同一机构任职且时间重叠，或共同参与项目','','','',0,'v1.8',1,0,'inferred',1,NULL,'283aaf94-07a4-5bdb-af0a-d521b703790b','283aaf94-07a4-5bdb-af0a-d521b703790b','Expert','Expert',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('7b3c1d2e-0b6f-573d-8656-5227fe9fb4bf','co-author','dev','relation','CO_AUTHOR','论文合作','共同发表同一论文','','','',0,'v1.8',0,0,'inferred',1,NULL,'283aaf94-07a4-5bdb-af0a-d521b703790b','283aaf94-07a4-5bdb-af0a-d521b703790b','Expert','Expert',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('813d05a7-289f-5d16-80c6-2119df9102e9','report-field','dev','relation','REPORT_FIELD','报告研究方向','关键词标准化','','','',0,'v1.8',31,0,'fact',1,NULL,'2c0881ca-0e78-541a-9415-23d4967f1ca5','dbaa2a42-66f7-5061-8175-c675ed08212b','Report','ResearchField',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('84a8c5dd-8703-58cd-a1b8-faafafdb4a66','report-related-project','dev','relation','REPORT_RELATED_PROJECT','报告关联项目','相关项目对齐','','','',0,'v1.8',30,0,'fact',1,NULL,'2c0881ca-0e78-541a-9415-23d4967f1ca5','51414fdf-6327-5724-b694-adb492403cc4','Report','Project',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('863a15c3-7648-5da3-bf4f-130f4d040aa3','has-financial-record','dev','relation','HAS_FINANCIAL_RECORD','机构年度财务','需要保留年度历史时生成','','','',0,'v1.8',42,0,'fact',1,NULL,'ffe23d4b-7198-523a-b436-cacb0dde45ff',NULL,'Organization','FinancialRecord',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('8e6e34dc-3461-552a-b933-0bab08120496','belongs-to-patent-family','dev','relation','BELONGS_TO_PATENT_FAMILY','专利属于家族','专利家族对齐后生成','','','',0,'v1.8',43,0,'fact',1,NULL,'93c39017-e78f-5e75-b87f-98be59a43e12',NULL,'Patent','PatentFamily',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('93329e93-7c00-53b6-9d83-adc9d573f3ce','product-chain-node','dev','relation','PRODUCT_CHAIN_NODE','产品关联产业链节点','标准产品连接所属节点','','','',0,'v1.8',39,0,'fact',1,NULL,'384239f4-0792-5f53-836b-42352b38e7e2','e4f64b75-427f-5af5-8fa3-685dfcce1d11','Product','IndustryChainNode',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('93c39017-e78f-5e75-b87f-98be59a43e12','patent','dev','entity','Patent','专利','专利成果、法律状态、权利人与技术分类','patent_id / publication_number / application_number','patent_id','dwd_patent',0,'v1.8',4,1,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('956aefcd-fe65-52ce-9b6e-de35b8d1b86a','works-at','dev','relation','WORKS_AT','任职','工作经历抽取机构、职位和时间','','','',0,'v1.8',2,0,'fact',1,NULL,NULL,'ffe23d4b-7198-523a-b436-cacb0dde45ff','Expert / Person','Organization',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('97bd0b0c-6ad8-51c5-9496-6fc0d6de8abc','funded-by','dev','relation','FUNDED_BY','项目受资助','资助机构对齐后生成','','','',0,'v1.8',16,0,'fact',1,NULL,'51414fdf-6327-5724-b694-adb492403cc4','ffe23d4b-7198-523a-b436-cacb0dde45ff','Project','Organization',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('a65389aa-5743-5973-ab72-e12eb1070e3e','subsidiary-of','dev','relation','SUBSIDIARY_OF','子公司关系','子公司对齐后生成','','','',0,'v1.8',10,0,'fact',1,NULL,'ffe23d4b-7198-523a-b436-cacb0dde45ff','ffe23d4b-7198-523a-b436-cacb0dde45ff','Organization','Organization',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('b041dc73-3734-51e3-af11-4facd321e313','person','dev','entity','Person','通用人员','已确认为同一自然人，但不能确认为专家时使用','person_id','person_id','dwd_org_executive / dwd_org_shareholder / dwd_patent_inventor / dwd_paper_author',0,'v1.8',11,0,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('b2484748-bd31-5252-8c1d-303bfb732b0d','report-related-paper','dev','relation','REPORT_RELATED_PAPER','报告关联论文','相关文献对齐','','','',0,'v1.8',29,0,'fact',1,NULL,'2c0881ca-0e78-541a-9415-23d4967f1ca5','02603b0f-a422-5fd0-8d3a-53be348e57ec','Report','Paper',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('b2fb5975-96a6-51cd-bb47-777f15f71a2f','published-in','dev','relation','PUBLISHED_IN','论文发表于','ISSN、EISSN 或出版物名对齐','','','',0,'v1.8',5,0,'fact',1,NULL,'02603b0f-a422-5fd0-8d3a-53be348e57ec','d16dcd11-580e-594d-9443-f4fd4ab3a1ea','Paper','Publication',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('b6697771-7e65-5743-bf76-b28682c20362','patent-cites','dev','relation','PATENT_CITES','专利引用','被引用专利对齐后生成','','','',0,'v1.8',26,0,'fact',1,NULL,'93c39017-e78f-5e75-b87f-98be59a43e12','93c39017-e78f-5e75-b87f-98be59a43e12','Patent','Patent',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('bf904999-ee14-5755-bdc8-3b2bfd106ed8','chain-event-impact','dev','relation','CHAIN_EVENT_IMPACT','产业链事件影响','事件热度、关联企业数、政策影响和趋势','','','',0,'v1.8',7,0,'inferred',1,NULL,'e4f64b75-427f-5af5-8fa3-685dfcce1d11','67702440-021d-5db9-8a73-e13a5c11ce4f','IndustryChainNode','Event',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('c4ecb923-01bd-5416-83ac-1714f3efbbe3','c-i-t-e-s','dev','relation','CITES','论文引用','DOI、论文 ID 或题名作者对齐','','','',0,'v1.8',6,0,'fact',1,NULL,'02603b0f-a422-5fd0-8d3a-53be348e57ec','02603b0f-a422-5fd0-8d3a-53be348e57ec','Paper','Paper',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('c76c7f13-463f-50f3-9c78-3595613404cc','a-l-u-m-n-i','dev','relation','ALUMNI','校友关系','同校就读，结合专业、学历和时间','','','',0,'v1.8',2,0,'inferred',1,NULL,'283aaf94-07a4-5bdb-af0a-d521b703790b','283aaf94-07a4-5bdb-af0a-d521b703790b','Expert','Expert',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('cc1b8434-bed8-5d05-9135-d8e854f6d11a','affiliated-with','dev','relation','AFFILIATED_WITH','作者发表时单位','论文作者单位对齐后生成','','','',0,'v1.8',4,0,'fact',1,NULL,NULL,'ffe23d4b-7198-523a-b436-cacb0dde45ff','Expert / Person','Organization',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('cdac3e3e-22d1-5e63-86d4-52e8baa67523','industry-chain','dev','entity','IndustryChain','产业链','表示整条产业链，与 IndustryChainNode 明确分层','chain_code','chain_code','dim_industry_chain / dwd_industry_chain_info',0,'v1.8',13,0,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('ce4edf2d-7c54-5343-a6ef-45a92b53d4c5','policy-published-by','dev','relation','POLICY_PUBLISHED_BY','政策发布部门','发布部门对齐后生成','','','',0,'v1.8',34,0,'fact',1,NULL,'62300f5f-af9b-543f-8dac-aac0aee5e80e','ffe23d4b-7198-523a-b436-cacb0dde45ff','Policy','Organization',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('d16dcd11-580e-594d-9443-f4fd4ab3a1ea','publication','dev','entity','Publication','期刊 / 会议 / 出版物','论文发表载体及其动态指标','ISSN / EISSN / publication_id','ISSN / EISSN / publication_id','dim_publication / dwd_journal',0,'v1.8',12,0,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('d526bf2d-ca54-5946-9f55-5d8ce6b7eaa1','participate-in-project','dev','relation','PARTICIPATE_IN_PROJECT','机构参与项目','参与机构拆分对齐后生成','','','',0,'v1.8',17,0,'fact',1,NULL,'ffe23d4b-7198-523a-b436-cacb0dde45ff','51414fdf-6327-5724-b694-adb492403cc4','Organization','Project',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('d7df9862-cebd-5b1f-9834-fe5d9b408b39','lead-project','dev','relation','LEAD_PROJECT','主持项目','项目主持人对齐后生成','','','',0,'v1.8',14,0,'fact',1,NULL,'283aaf94-07a4-5bdb-af0a-d521b703790b','51414fdf-6327-5724-b694-adb492403cc4','Expert','Project',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('db10c54d-fb60-59e6-95e0-8b152e51e31b','author-of-report','dev','relation','AUTHOR_OF_REPORT','报告作者','报告作者对齐后生成','','','',0,'v1.8',27,0,'fact',1,NULL,NULL,'2c0881ca-0e78-541a-9415-23d4967f1ca5','Expert / Person','Report',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('dbaa2a42-66f7-5061-8175-c675ed08212b','research-field','dev','entity','ResearchField','研究方向 / 技术领域','统一研究方向、学科、关键词、IPC 与产业技术领域','field_id / discipline_code / 标准名','field_id / discipline_code','dim_research_field / dim_discipline_code',0,'v1.8',10,1,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('dc199ce5-6116-5350-80cd-ddbabeaf69e1','upstream-downstream','dev','relation','UPSTREAM_DOWNSTREAM','产业链上下游','downstream_link_code 生成','','','',0,'v1.8',37,0,'fact',1,NULL,'e4f64b75-427f-5af5-8fa3-685dfcce1d11','e4f64b75-427f-5af5-8fa3-685dfcce1d11','IndustryChainNode','IndustryChainNode',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('e4f64b75-427f-5af5-8fa3-685dfcce1d11','industry-chain-node','dev','entity','IndustryChainNode','产业链节点','产业链的上游、中游、下游及具体环节','chain_code + node_id','chain_code + node_id','dwd_industry_chain_info',0,'v1.8',8,1,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('eccbbbbe-267c-5a06-aaa4-1071bc9b4a6e','direct-relation','dev','relation','DIRECT_RELATION','专家直接关系','论文、项目、专利、同事、校友和企业合作综合判定','','','',0,'v1.8',3,0,'inferred',1,NULL,'283aaf94-07a4-5bdb-af0a-d521b703790b','283aaf94-07a4-5bdb-af0a-d521b703790b','Expert','Expert',NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50'),('ffe23d4b-7198-523a-b436-cacb0dde45ff','organization','dev','entity','Organization','机构 / 企业','高校、科研机构、企业、医院和政府机构统一建模，用 org_category 区分','org_id / external_id / credit_code','org_id','dwd_org_reg_info / dwd_forg_base_info',0,'v1.8',1,1,NULL,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'pending',NULL,NULL,1,0,NULL,'2026-09-04 03:56:50','2026-09-04 03:56:50');
/*!40000 ALTER TABLE `kg_schema_definition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kg_schema_mapping`
--

DROP TABLE IF EXISTS `kg_schema_mapping`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kg_schema_mapping` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `schema_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_kg_schema_mapping_source` (`schema_id`,`source_name`),
  CONSTRAINT `kg_schema_mapping_ibfk_1` FOREIGN KEY (`schema_id`) REFERENCES `kg_schema_definition` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Schema 来源对象映射';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kg_schema_mapping`
--

LOCK TABLES `kg_schema_mapping` WRITE;
/*!40000 ALTER TABLE `kg_schema_mapping` DISABLE KEYS */;
INSERT INTO `kg_schema_mapping` VALUES ('14cd272b-f9a4-4c43-97f5-1f36e528270b','62300f5f-af9b-543f-8dac-aac0aee5e80e','dwd_zck_intl_policy',1),('1bfc4b2a-996d-44cf-ab85-7717f8755856','62300f5f-af9b-543f-8dac-aac0aee5e80e','dws_zck_policy',0),('1ec3595c-0ef4-492b-b276-6aa8907d34f4','67702440-021d-5db9-8a73-e13a5c11ce4f','dwd_financing_event',2),('20313890-5c9f-4c84-9483-5c0e57ecac1b','b041dc73-3734-51e3-af11-4facd321e313','dwd_org_executive',0),('2349bbcd-d69e-4d15-ae08-53ab33a21626','384239f4-0792-5f53-836b-42352b38e7e2','dwd_org_industry_chain_prod_dtl',0),('2d8ce565-0ce1-45ac-9eac-2071c48295b4','b041dc73-3734-51e3-af11-4facd321e313','dwd_paper_author',3),('362a0051-6257-4c31-8d5f-3aaf2f4b5740','ffe23d4b-7198-523a-b436-cacb0dde45ff','dwd_org_reg_info',0),('3abc2f52-2702-4fe0-a107-32642c57852c','d16dcd11-580e-594d-9443-f4fd4ab3a1ea','dim_publication',0),('4015bcb8-7c94-4fdc-8b10-adbe6aa0e592','51414fdf-6327-5724-b694-adb492403cc4','dwd_zh_project',0),('403a6060-32b4-4a3b-9c5c-7ba4fe4eaf7e','67702440-021d-5db9-8a73-e13a5c11ce4f','dwd_org_important_news_info',0),('58e63fc4-0c22-47ad-bb89-d4d5e7d14e36','cdac3e3e-22d1-5e63-86d4-52e8baa67523','dim_industry_chain',0),('5ce4af61-1f42-42fc-ba1e-a8eec797c371','93c39017-e78f-5e75-b87f-98be59a43e12','dwd_patent_inventor',1),('5e49f521-2b0b-4aea-8425-1c512d3ef521','d16dcd11-580e-594d-9443-f4fd4ab3a1ea','dwd_journal',1),('62789ed9-d031-45e9-9fd8-5735ef3d832d','2c0881ca-0e78-541a-9415-23d4967f1ca5','dwd_en_report',1),('6768fbf8-5a07-4ef0-a0a0-b22a91bbff37','283aaf94-07a4-5bdb-af0a-d521b703790b','dwd_paper_author',1),('77a01aa0-f47c-4cbf-a487-9ffd55a010c0','cdac3e3e-22d1-5e63-86d4-52e8baa67523','dwd_industry_chain_info',1),('8307e59a-66e7-4761-af0c-a1cd0651fe16','283aaf94-07a4-5bdb-af0a-d521b703790b','dwd_patent_inventor',3),('8768ce87-dfb8-4e17-9b39-066f328019bf','ffe23d4b-7198-523a-b436-cacb0dde45ff','dwd_forg_base_info',1),('8cdae024-a76f-4441-b84e-fbd46b2e199f','51414fdf-6327-5724-b694-adb492403cc4','dwd_en_project',1),('a2cfafd0-bc98-45c6-98cd-d690be5e5668','dbaa2a42-66f7-5061-8175-c675ed08212b','dim_research_field',0),('b3e0869a-edbb-4807-8885-bdf2e18950e6','dbaa2a42-66f7-5061-8175-c675ed08212b','dim_discipline_code',1),('c559a468-5402-4383-815f-44e94a4b39eb','dbaa2a42-66f7-5061-8175-c675ed08212b','dim_ipc',2),('c6254678-0f03-4e48-a834-625822ae4cbb','283aaf94-07a4-5bdb-af0a-d521b703790b','dwd_scholar',0),('c98c3fbf-662b-481d-9986-6da7a6494849','02603b0f-a422-5fd0-8d3a-53be348e57ec','dwd_en_paper_detail',1),('d1f16ec3-b6e0-4247-9e67-3705d9df7543','02603b0f-a422-5fd0-8d3a-53be348e57ec','dwd_paper_reference',2),('d2e0b3f0-5d28-4f21-8d5d-9f5622474528','02603b0f-a422-5fd0-8d3a-53be348e57ec','dwd_zh_paper_detail',0),('d4cd76ba-7c70-4014-9b3c-f630cee9fc92','67702440-021d-5db9-8a73-e13a5c11ce4f','dwd_industry_chain_news_info',1),('d704f31f-2219-405b-91a2-90f68ac9087d','51414fdf-6327-5724-b694-adb492403cc4','dwd_project_output',2),('dc2b7023-2750-4b6f-8fc6-6331d163a634','b041dc73-3734-51e3-af11-4facd321e313','dwd_org_shareholder',1),('e6af6055-3c91-41d8-b1bd-354becf3acd7','2c0881ca-0e78-541a-9415-23d4967f1ca5','dwd_zh_report',0),('e782f08f-5757-4a19-afe0-47154435fd15','ffe23d4b-7198-523a-b436-cacb0dde45ff','dwd_paper_affiliation',2),('ef9e3b89-b7e0-4b78-9bbe-9e49e6905030','62300f5f-af9b-543f-8dac-aac0aee5e80e','dwd_policy_department',2),('f4571f89-0c21-4139-9c6d-d3cb996c97fd','ffe23d4b-7198-523a-b436-cacb0dde45ff','dwd_patent_applicant',3),('f5baadef-18d8-466f-ab08-820b5f81bf69','93c39017-e78f-5e75-b87f-98be59a43e12','dwd_patent_applicant',2),('fa70cf69-0441-4973-9837-7146208b9ff3','93c39017-e78f-5e75-b87f-98be59a43e12','dwd_patent',0),('fb3d97c2-bcf5-4697-b80e-6066c1417c60','b041dc73-3734-51e3-af11-4facd321e313','dwd_patent_inventor',2),('fd367f1d-23a0-43cb-a6a4-e10523fa890b','283aaf94-07a4-5bdb-af0a-d521b703790b','dwd_project_person',2),('fd9f036b-956b-42f6-90ce-6ccbb3ecf6f5','2c0881ca-0e78-541a-9415-23d4967f1ca5','dwd_report_author',2),('ffb5a98a-f15d-4a87-b3ef-0c25b89cd93f','e4f64b75-427f-5af5-8fa3-685dfcce1d11','dwd_industry_chain_info',0);
/*!40000 ALTER TABLE `kg_schema_mapping` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kg_schema_property`
--

DROP TABLE IF EXISTS `kg_schema_property`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kg_schema_property` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `schema_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `data_type` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `required` tinyint(1) NOT NULL,
  `rule` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `position` int NOT NULL,
  `is_deleted` tinyint(1) NOT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_kg_schema_property_name` (`schema_id`,`name`),
  CONSTRAINT `kg_schema_property_ibfk_1` FOREIGN KEY (`schema_id`) REFERENCES `kg_schema_definition` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Schema 属性与约束';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kg_schema_property`
--

LOCK TABLES `kg_schema_property` WRITE;
/*!40000 ALTER TABLE `kg_schema_property` DISABLE KEYS */;
INSERT INTO `kg_schema_property` VALUES ('003eea96-6ef8-4b4a-b38b-192d7fcf3a5a','7b3c1d2e-0b6f-573d-8656-5227fe9fb4bf','source','string',0,'','core',0,0,NULL),('010c5bf9-e6e2-4a2a-a56c-385465854a10','0b489152-3622-5fc2-9682-3704a8bd8d5b','source','string',0,'','core',0,0,NULL),('01538a9d-448b-4b0f-812d-02868e85479d','e4f64b75-427f-5af5-8fa3-685dfcce1d11','parent_id','string',0,'','core',3,0,NULL),('02e25ad5-de33-4f91-94dc-086a0b0acdb9','18cf138f-b599-52e3-9295-4f2264c6cc99','target','string',0,'','core',1,0,NULL),('034bf5fd-b05f-4725-be6d-67c541fa940b','381db037-df95-5c9a-82c4-310da83fa9c2','target','string',0,'','core',1,0,NULL),('05d0af80-6bd1-4944-a101-c36e26dddc27','2924fc2d-afae-5a53-91f2-da22af424c8b','source','string',0,'','core',0,0,NULL),('075018e8-b945-4539-9c6f-91b1b4a40ddf','28cbffc8-8f01-5c28-82d8-23b2a816c538','source','string',0,'','core',0,0,NULL),('07a266d2-d61d-4c24-a2fd-01edea3cd4b5','74e42d05-d3a0-53f9-8737-c9f4cb0abeba','target','string',0,'','core',1,0,NULL),('095efcfd-a407-4f1c-938a-508749dc539e','2c0881ca-0e78-541a-9415-23d4967f1ca5','title_zh','string',0,'','core',0,0,NULL),('0a05355d-54b1-48d7-b12c-15fff9e9de2f','d7df9862-cebd-5b1f-9834-fe5d9b408b39','source','string',0,'','core',0,0,NULL),('0b489e98-334c-41f0-bd78-4e211ac9052c','51414fdf-6327-5724-b694-adb492403cc4','approval_time','string',0,'','core',5,0,NULL),('0dde28bf-aa9b-4c31-a399-b0b7f47d9004','02603b0f-a422-5fd0-8d3a-53be348e57ec','abstract_en','string',0,'','core',5,0,NULL),('0f31824f-52c0-47e3-8936-781f35a8baf1','6d74ae2d-6838-5493-84c2-5c81382adc14','source','string',0,'','core',0,0,NULL),('0f67d8ad-74da-4e9f-b0dd-d4fcfd854f4b','42931488-6ba7-52d5-940d-c0a9b94904f0','target','string',0,'','core',1,0,NULL),('0fadd0ce-561d-4087-a0cf-d459d80e7ff3','b2fb5975-96a6-51cd-bb47-777f15f71a2f','source','string',0,'','core',0,0,NULL),('10e22c15-b2d4-4cbb-a8a7-ed7b8433f795','74e42d05-d3a0-53f9-8737-c9f4cb0abeba','source','string',0,'','core',0,0,NULL),('12029825-c067-43ef-ad44-3a42d2869caf','956aefcd-fe65-52ce-9b6e-de35b8d1b86a','source','string',0,'','core',0,0,NULL),('122889ae-661a-475d-983e-591aae6f1d9f','67702440-021d-5db9-8a73-e13a5c11ce4f','summary','string',0,'','core',3,0,NULL),('16583fa5-a1be-4d64-99e4-a870509d4d29','09be6ac2-e279-553a-a397-85ecbb7461b6','source','string',0,'','core',0,0,NULL),('17581c94-f59e-4628-8a20-354caacecb56','c4ecb923-01bd-5416-83ac-1714f3efbbe3','target','string',0,'','core',1,0,NULL),('196fe84f-7eb8-4ec1-b269-f993727b6116','e4f64b75-427f-5af5-8fa3-685dfcce1d11','node_stage','string',0,'','core',4,0,NULL),('1a64a2d3-5b9b-4b1d-a101-dfd00a1b9b7c','cc1b8434-bed8-5d05-9135-d8e854f6d11a','source','string',0,'','core',0,0,NULL),('1a8a6394-7379-4add-8acc-2a28df84f96c','07787f00-01f2-581b-9edb-a46fe87c753b','target','string',0,'','core',1,0,NULL),('1bebf7e1-ccc7-4083-9c81-ab9a173a6342','62300f5f-af9b-543f-8dac-aac0aee5e80e','按政策源更新','string',0,'','dynamic',8,0,NULL),('1e0d57d9-6040-40d1-8238-31fb21990df3','863a15c3-7648-5da3-bf4f-130f4d040aa3','target','string',0,'','core',1,0,NULL),('244d9d2d-f547-4537-a64a-edbe5b4467fa','c76c7f13-463f-50f3-9c78-3595613404cc','target','string',0,'','core',1,0,NULL),('247a822e-519e-4d60-9a61-c605122ecf34','a65389aa-5743-5973-ab72-e12eb1070e3e','source','string',0,'','core',0,0,NULL),('24a21975-ffe9-46ef-9c2d-76ce8c4373a3','c76c7f13-463f-50f3-9c78-3595613404cc','source','string',0,'','core',0,0,NULL),('25413a9e-fb7e-4491-95a7-7adc7e51adef','67702440-021d-5db9-8a73-e13a5c11ce4f','title','string',0,'','core',1,0,NULL),('25881d03-7537-440b-b666-725040d0965c','93329e93-7c00-53b6-9d83-adc9d573f3ce','source','string',0,'','core',0,0,NULL),('29223978-53ff-4223-8ff6-1756ba486d1e','67702440-021d-5db9-8a73-e13a5c11ce4f','source_url','string',0,'','core',4,0,NULL),('29808388-3516-427e-aa6a-b70093701b63','09be6ac2-e279-553a-a397-85ecbb7461b6','target','string',0,'','core',1,0,NULL),('2a83cc5f-b5b8-451b-a1b4-b4a0690603d6','73458f60-7701-5d45-afd9-7adb82c615fb','target','string',0,'','core',1,0,NULL),('2b9f3505-a1db-4ae4-be26-b7bf426b7ab9','ce4edf2d-7c54-5343-a6ef-45a92b53d4c5','target','string',0,'','core',1,0,NULL),('2c98053c-a1e6-4128-9590-6573868f86aa','51414fdf-6327-5724-b694-adb492403cc4','discipline_code','string',0,'','core',4,0,NULL),('2decd502-b4d0-42d2-a86a-c36780910dd0','8e6e34dc-3461-552a-b933-0bab08120496','target','string',0,'','core',1,0,NULL),('2e19a8bc-79d0-4713-b81d-49df0f1ab048','59cb4b88-ee38-5e0d-b72d-158a543e5d28','target','string',0,'','core',1,0,NULL),('2e5a801d-a814-45f2-8f2f-fd4c4adc78da','b2484748-bd31-5252-8c1d-303bfb732b0d','source','string',0,'','core',0,0,NULL),('2ff877ee-c8c0-44c1-b99e-fdf101cd7bf1','6dc80b11-5fc1-560e-8821-71918d65ed41','target','string',0,'','core',1,0,NULL),('2ffa0386-6b86-40fb-b6cc-81b247973143','02603b0f-a422-5fd0-8d3a-53be348e57ec','publish_year','string',0,'','core',3,0,NULL),('3222ed6e-74f9-43e3-a949-469c0a2faa78','62300f5f-af9b-543f-8dac-aac0aee5e80e','keywords','string',0,'','core',6,0,NULL),('336e840f-e71f-4a07-a923-0130676d1f0f','384239f4-0792-5f53-836b-42352b38e7e2','product_seq','string',0,'','core',1,0,NULL),('33ee07d1-085b-4554-b5e3-4965e732fc17','1a76477d-c011-5c01-a24d-5ed21bb7fc6d','source','string',0,'','core',0,0,NULL),('342ab73e-db9e-43e6-a926-1cf47756621a','62300f5f-af9b-543f-8dac-aac0aee5e80e','region','string',0,'','core',5,0,NULL),('385aa488-78f0-4d1a-9c49-c129d48be44e','67702440-021d-5db9-8a73-e13a5c11ce4f','subject','string',0,'','core',5,0,NULL),('3a58e8d8-005b-451a-8882-742a19cc66dc','bf904999-ee14-5755-bdc8-3b2bfd106ed8','source','string',0,'','core',0,0,NULL),('3ae7766d-ec53-402e-ac36-087f8209d9c3','02603b0f-a422-5fd0-8d3a-53be348e57ec','keywords','string',0,'','core',6,0,NULL),('3bc87ed5-300f-4d79-8f98-9f06e41b7a05','62300f5f-af9b-543f-8dac-aac0aee5e80e','title','string',0,'','core',0,0,NULL),('3be7f977-2861-491d-9d52-5918b5fcdf6e','51414fdf-6327-5724-b694-adb492403cc4','research_period','string',0,'','dynamic',7,0,NULL),('3d547aba-ece9-4907-a163-a810a18ff13b','dbaa2a42-66f7-5061-8175-c675ed08212b','alias','string',0,'','core',1,0,NULL),('3e5a34e2-855e-47d9-bab0-86f695b14c21','84a8c5dd-8703-58cd-a1b8-faafafdb4a66','source','string',0,'','core',0,0,NULL),('3f1e4c27-1f39-4d15-bb44-fcae20c3d62a','601f5f43-0da8-57d0-9009-eccbe3fb5ad0','source','string',0,'','core',0,0,NULL),('3f9c37a8-d51a-4826-babd-ad0ee74f0dd9','db10c54d-fb60-59e6-95e0-8b152e51e31b','source','string',0,'','core',0,0,NULL),('42b790af-2454-44c6-b853-3c568a348841','62300f5f-af9b-543f-8dac-aac0aee5e80e','issueno','string',0,'','core',3,0,NULL),('42dc26ac-e882-4c48-bc9d-5726de0e1c45','09854c48-54fa-5ee7-9b90-4a70d13bf0b4','target','string',0,'','core',1,0,NULL),('43bd5a6b-0fe6-47a9-b858-6e79de74dec9','ffe23d4b-7198-523a-b436-cacb0dde45ff','name_en','string',0,'','core',1,0,NULL),('446cf48f-6a34-4016-bd45-d9266b6b8169','28cbffc8-8f01-5c28-82d8-23b2a816c538','target','string',0,'','core',1,0,NULL),('447abb8c-bf51-4f8d-bc05-d039abd220e2','62300f5f-af9b-543f-8dac-aac0aee5e80e','content','string',0,'','core',1,0,NULL),('44cc4396-30f5-44ef-a692-2e569cc8dc3b','283aaf94-07a4-5bdb-af0a-d521b703790b','bio_en','string',0,'','core',5,0,NULL),('45124618-61d5-48b6-8974-f8926fab541c','0b489152-3622-5fc2-9682-3704a8bd8d5b','target','string',0,'','core',1,0,NULL),('4528c5e4-492d-4743-9f92-216e7acf0846','0085cb12-f8da-558c-929f-f4a28b678a34','source','string',0,'','core',0,0,NULL),('45a2272e-42f5-4f30-a269-0e1e4884c1b5','11373021-4da5-5c58-a0a0-92d68cce22e3','target','string',0,'','core',1,0,NULL),('4628b7fe-ecec-4a89-b987-808e840f9582','51414fdf-6327-5724-b694-adb492403cc4','project_level','string',0,'','core',3,0,NULL),('463b8b00-e191-481e-a6b5-de4f7b24671c','3256818a-fcb8-54d2-8524-81b3e07f1806','source','string',0,'','core',0,0,NULL),('48f8a895-6917-405c-96f4-fcba8c02a6f7','02603b0f-a422-5fd0-8d3a-53be348e57ec','title_en','string',0,'','core',2,0,NULL),('492c513e-cc50-44ca-af91-6fc87c7e72f4','283aaf94-07a4-5bdb-af0a-d521b703790b','avatar','string',0,'','core',2,0,NULL),('4bd68b24-a14d-4a21-92ff-4123247360df','02603b0f-a422-5fd0-8d3a-53be348e57ec','is_open_access','string',0,'','dynamic',8,0,NULL),('4d602a45-ac19-40a7-aca4-e9087a2dbfd4','956aefcd-fe65-52ce-9b6e-de35b8d1b86a','target','string',0,'','core',1,0,NULL),('4fbbaeac-9332-4a75-a36f-940f3b23798e','02603b0f-a422-5fd0-8d3a-53be348e57ec','title_zh','string',0,'','core',1,0,NULL),('503c4fa9-0970-4bd8-85d0-d6529f1f869c','617e742a-bb5d-5d10-bd20-66a4692e7c91','source','string',0,'','core',0,0,NULL),('52180185-42ab-4b7c-b42d-36d8aca82e34','2c0881ca-0e78-541a-9415-23d4967f1ca5','keywords_zh','string',0,'','core',5,0,NULL),('5378fab2-9752-4509-86f2-3cc1bf1eea3e','2c0881ca-0e78-541a-9415-23d4967f1ca5','publication_date','string',0,'','dynamic',6,0,NULL),('53dd3788-e349-43bb-90c9-7fa416aca16f','51e13a94-f251-5c1f-8e9d-57a01cd7a920','source','string',0,'','core',0,0,NULL),('53ff08b2-8844-48d3-bb00-74a9cfd5f46f','93329e93-7c00-53b6-9d83-adc9d573f3ce','target','string',0,'','core',1,0,NULL),('54517326-c992-4e60-9110-4f8a5011479b','02603b0f-a422-5fd0-8d3a-53be348e57ec','abstract_zh','string',0,'','core',4,0,NULL),('55f9e9de-f7c0-4bb9-b10d-9e93a13affef','283aaf94-07a4-5bdb-af0a-d521b703790b','name_en','string',0,'','core',1,0,NULL),('578029fb-3f8f-49a2-8ad4-384a61fe2d42','84a8c5dd-8703-58cd-a1b8-faafafdb4a66','target','string',0,'','core',1,0,NULL),('5849900a-e052-4fbb-8e3f-ffa26750d3f9','51414fdf-6327-5724-b694-adb492403cc4','project_source','string',0,'','core',2,0,NULL),('5aa92eb2-932e-471a-bfaf-0ae02ebf67cf','e4f64b75-427f-5af5-8fa3-685dfcce1d11','node_name','string',0,'','core',0,0,NULL),('5c799400-2822-457d-b557-f7cda1391817','c4ecb923-01bd-5416-83ac-1714f3efbbe3','source','string',0,'','core',0,0,NULL),('612f1b8a-a610-47b6-9f74-bcd33fde0408','d526bf2d-ca54-5946-9f55-5d8ce6b7eaa1','source','string',0,'','core',0,0,NULL),('62cef67b-a2cf-4961-9c24-4aa10ebcac82','62300f5f-af9b-543f-8dac-aac0aee5e80e','url','string',0,'','core',2,0,NULL),('62ed9c0b-f5f2-49bc-b3c0-3987bcb0f1bd','283aaf94-07a4-5bdb-af0a-d521b703790b','h_index','string',0,'','dynamic',8,0,NULL),('63495391-3d6c-4201-942e-5a6249a6c1d1','97bd0b0c-6ad8-51c5-9496-6fc0d6de8abc','target','string',0,'','core',1,0,NULL),('64f84cb3-7d2a-4a18-9152-bd627b2edc88','813d05a7-289f-5d16-80c6-2119df9102e9','target','string',0,'','core',1,0,NULL),('68c6e729-c60e-4db3-8a78-149604f5999d','d16dcd11-580e-594d-9443-f4fd4ab3a1ea','ISSN','string',0,'','core',0,0,NULL),('69e2cf26-cb1a-4c3e-a493-d347ea97501f','3256818a-fcb8-54d2-8524-81b3e07f1806','target','string',0,'','core',1,0,NULL),('6d1417b7-82d4-4445-bff1-b405187976eb','2924fc2d-afae-5a53-91f2-da22af424c8b','target','string',0,'','core',1,0,NULL),('6dbff0a2-6310-4c9d-9f3f-6ee64b7fd255','d526bf2d-ca54-5946-9f55-5d8ce6b7eaa1','target','string',0,'','core',1,0,NULL),('702fa713-b7e0-4559-a0e8-e150adedc8d2','59cb4b88-ee38-5e0d-b72d-158a543e5d28','source','string',0,'','core',0,0,NULL),('71d72712-9619-4ac7-a45c-8adb018f5cdd','384239f4-0792-5f53-836b-42352b38e7e2','product_name','string',0,'','core',0,0,NULL),('72d9dc23-95a4-4654-875d-b2519128b610','384239f4-0792-5f53-836b-42352b38e7e2','所属节点和企业映射','string',0,'','dynamic',4,0,NULL),('73081986-20aa-4df2-9489-8aa7b4bf489f','62300f5f-af9b-543f-8dac-aac0aee5e80e','publish_department','string',0,'','core',7,0,NULL),('780f1f61-3465-4e2c-9149-0fd5bc262dba','67702440-021d-5db9-8a73-e13a5c11ce4f','event_time','string',0,'','core',2,0,NULL),('7873cf47-9fb3-4909-9fb4-d7d0f0ca9fbf','51414fdf-6327-5724-b694-adb492403cc4','project_number','string',0,'','core',0,0,NULL),('7c88f700-eb90-4c82-8254-46f18a62a1fc','11373021-4da5-5c58-a0a0-92d68cce22e3','source','string',0,'','core',0,0,NULL),('7cb63dcf-0313-4aab-9922-171aee0bc73b','ffe23d4b-7198-523a-b436-cacb0dde45ff','external_id','string',0,'','core',2,0,NULL),('7ee7f78c-89a0-4670-b8a3-e11ec4f21021','617e742a-bb5d-5d10-bd20-66a4692e7c91','target','string',0,'','core',1,0,NULL),('7eea5895-d317-4f6a-aedf-6985df26ad54','eccbbbbe-267c-5a06-aaa4-1071bc9b4a6e','source','string',0,'','core',0,0,NULL),('7f7d2471-46a6-4f30-9068-298363e66de0','ce4edf2d-7c54-5343-a6ef-45a92b53d4c5','source','string',0,'','core',0,0,NULL),('80414a4a-97e2-4f3b-96c4-47f563b6e270','5390a50c-76dc-5c73-9539-7dd545ffa68d','target','string',0,'','core',1,0,NULL),('80c5698b-5b5c-4594-b164-f63c4e467af0','231790be-b6dd-5d80-affc-c262840d2a68','target','string',0,'','core',1,0,NULL),('817a4d71-a7b9-47c2-83ae-64f3d3a8481c','ffe23d4b-7198-523a-b436-cacb0dde45ff','financial_metrics','string',0,'','dynamic',9,0,NULL),('84ffdadf-e582-46e9-9901-9c540713116c','283aaf94-07a4-5bdb-af0a-d521b703790b','organization_name_zh','string',0,'','core',3,0,NULL),('85e1e4f1-333b-4c14-ae5f-6d19a6ce073b','283aaf94-07a4-5bdb-af0a-d521b703790b','paper_count','string',0,'','dynamic',6,0,NULL),('88338b96-5cca-4608-88fd-5dd0f85740c2','1c33af51-947b-5c65-a242-b67c82a85781','source','string',0,'','core',0,0,NULL),('8cad8551-bbc3-4fa0-bdc2-d3959c35facc','ffe23d4b-7198-523a-b436-cacb0dde45ff','listing_status','string',0,'','dynamic',7,0,NULL),('8f87a4c2-1fdd-4cdf-990b-bd81615f3852','db10c54d-fb60-59e6-95e0-8b152e51e31b','target','string',0,'','core',1,0,NULL),('9138b0b6-11be-4ae8-ad69-4465d367c62b','6d74ae2d-6838-5493-84c2-5c81382adc14','target','string',0,'','core',1,0,NULL),('9271c3c2-82b8-420c-9c64-c12d811a4562','172c11d4-9a47-5467-843b-7830a09bd5b1','source','string',0,'','core',0,0,NULL),('92c989a4-4893-4305-a83c-b5a9f18931d5','18cf138f-b599-52e3-9295-4f2264c6cc99','source','string',0,'','core',0,0,NULL),('938fed9b-82b2-4bb7-9008-e36f2fb03781','eccbbbbe-267c-5a06-aaa4-1071bc9b4a6e','target','string',0,'','core',1,0,NULL),('961e1029-f610-48fc-b679-aa56386d4804','ffe23d4b-7198-523a-b436-cacb0dde45ff','registered_capital_value','string',0,'','dynamic',8,0,NULL),('97ba9e4c-f170-4368-ba87-a606eee587db','dbaa2a42-66f7-5061-8175-c675ed08212b','别名与上下位字典','string',0,'','dynamic',4,0,NULL),('9864573e-2c88-4c07-abbc-5cb1efe76f53','8e6e34dc-3461-552a-b933-0bab08120496','source','string',0,'','core',0,0,NULL),('99822525-748d-47c7-b520-fddf825decb3','231790be-b6dd-5d80-affc-c262840d2a68','source','string',0,'','core',0,0,NULL),('99876a71-7e91-42b1-8afe-ad00b4331aa0','384239f4-0792-5f53-836b-42352b38e7e2','company_name','string',0,'','core',2,0,NULL),('99e83600-0c65-4855-8a61-71d1f7df0315','283aaf94-07a4-5bdb-af0a-d521b703790b','bio_zh','string',0,'','core',4,0,NULL),('9b1dff05-2c9c-4f5c-9bda-1fca7ca6833a','cc1b8434-bed8-5d05-9135-d8e854f6d11a','target','string',0,'','core',1,0,NULL),('9bd7a103-412c-4228-b149-12febc68ea3d','02603b0f-a422-5fd0-8d3a-53be348e57ec','doi','string',0,'','core',0,0,NULL),('9c702623-1bba-468d-b374-7940c581c155','51414fdf-6327-5724-b694-adb492403cc4','title','string',0,'','core',1,0,NULL),('9de4dc3d-fed8-4244-992b-a419fceea41a','07787f00-01f2-581b-9edb-a46fe87c753b','source','string',0,'','core',0,0,NULL),('9e50fe9b-3f00-453f-9276-55dbc676369a','dc199ce5-6116-5350-80cd-ddbabeaf69e1','source','string',0,'','core',0,0,NULL),('9fce2ae0-a6f3-4279-b764-c6b149cd7e35','dbaa2a42-66f7-5061-8175-c675ed08212b','field_type','string',0,'','core',2,0,NULL),('a0993fc2-922e-4848-821a-8441d8ba42fa','51414fdf-6327-5724-b694-adb492403cc4','funded_amount','string',0,'','dynamic',6,0,NULL),('a0c46251-f5b5-4cbb-b26d-e77a85755fbe','384239f4-0792-5f53-836b-42352b38e7e2','credit_code','string',0,'','core',3,0,NULL),('a1fb0970-0cec-4e9f-b4e1-cb1f14b1bf4a','ffe23d4b-7198-523a-b436-cacb0dde45ff','address','string',0,'','core',6,0,NULL),('a2716afb-8c6c-4f25-8a59-41015d5dbcdc','172c11d4-9a47-5467-843b-7830a09bd5b1','target','string',0,'','core',1,0,NULL),('a2f35d80-d964-4484-b694-9baf77f41fe9','93c39017-e78f-5e75-b87f-98be59a43e12','legal_status','string',0,'','dynamic',6,0,NULL),('a3452409-a573-4bf5-a795-ab8df8df9dcb','dbaa2a42-66f7-5061-8175-c675ed08212b','parent_field','string',0,'','core',3,0,NULL),('a3f01840-afc1-4476-b5f4-26534f017d13','d7df9862-cebd-5b1f-9834-fe5d9b408b39','target','string',0,'','core',1,0,NULL),('a4b48f7b-bba4-470d-bfbe-1cc16e12f5a3','93c39017-e78f-5e75-b87f-98be59a43e12','application_number','string',0,'','core',1,0,NULL),('a813e760-78fe-4f6a-bc23-2071bb809fb8','1a76477d-c011-5c01-a24d-5ed21bb7fc6d','target','string',0,'','core',1,0,NULL),('a8c6e114-8354-497b-b763-0f1a7891cadd','b6697771-7e65-5743-bf76-b28682c20362','target','string',0,'','core',1,0,NULL),('a9e153ae-9ab4-4ccf-a8e6-edd20a9bf2fb','863a15c3-7648-5da3-bf4f-130f4d040aa3','source','string',0,'','core',0,0,NULL),('adaa7f83-6a81-452e-ba1d-4044969f1ea0','30ddf80e-08ab-52ee-a874-ee16bcd76ac7','source','string',0,'','core',0,0,NULL),('b2b2c114-5d83-4971-b768-a24bd808310f','0be976a5-5517-58dd-8155-ec80e942c308','target','string',0,'','core',1,0,NULL),('b3efe315-fc7f-4ade-95d3-fc0f4ffed3a1','b041dc73-3734-51e3-af11-4facd321e313','person_id','string',0,'','core',0,0,NULL),('b42a0df5-8dbd-464d-b4e0-562e037ae168','dc199ce5-6116-5350-80cd-ddbabeaf69e1','target','string',0,'','core',1,0,NULL),('b6f94c58-adc3-4d3e-a863-9ed52e13f446','283aaf94-07a4-5bdb-af0a-d521b703790b','citation_count','string',0,'','dynamic',7,0,NULL),('b7ccb0e0-64bb-4f19-ac92-1a776903a100','51e13a94-f251-5c1f-8e9d-57a01cd7a920','target','string',0,'','core',1,0,NULL),('b8abe1f3-e3b2-43f8-9256-0a70fb50f209','a65389aa-5743-5973-ab72-e12eb1070e3e','target','string',0,'','core',1,0,NULL),('b950097e-49dc-4d17-89da-3a50026edfae','e4f64b75-427f-5af5-8fa3-685dfcce1d11','level','string',0,'','core',2,0,NULL),('b9790515-6efa-4958-a0b8-27a5f320d031','67702440-021d-5db9-8a73-e13a5c11ce4f','impact_score','string',0,'','dynamic',7,0,NULL),('b9a6ff38-4091-4bb0-a5a2-9e3b0b30b8c9','b2484748-bd31-5252-8c1d-303bfb732b0d','target','string',0,'','core',1,0,NULL),('b9b48862-c71d-4088-9408-45e255eb611d','93c39017-e78f-5e75-b87f-98be59a43e12','publication_number','string',0,'','core',0,0,NULL),('b9fa4c77-0e48-42fa-9313-804aef54bcf8','6dc80b11-5fc1-560e-8821-71918d65ed41','source','string',0,'','core',0,0,NULL),('bd55b0aa-f1d4-4384-93ef-1174a5041584','ffe23d4b-7198-523a-b436-cacb0dde45ff','province','string',0,'','core',4,0,NULL),('c1f93654-be0a-4830-9e61-e87a440fe366','62300f5f-af9b-543f-8dac-aac0aee5e80e','pubtime','string',0,'','core',4,0,NULL),('c311d3cf-092b-4b2a-815e-70a4cf6fcf43','0045f86f-6b91-5c17-8c8b-fd129b4737d6','target','string',0,'','core',1,0,NULL),('c3660b56-e503-4b79-b75e-68a9693d88a6','67702440-021d-5db9-8a73-e13a5c11ce4f','event_type','string',0,'','core',0,0,NULL),('c425f824-10f6-4782-8c13-3b44cc857dfb','b2fb5975-96a6-51cd-bb47-777f15f71a2f','target','string',0,'','core',1,0,NULL),('c4b8aecc-5fc7-4631-91a9-e5c73421db2d','2c0881ca-0e78-541a-9415-23d4967f1ca5','abstract_zh','string',0,'','core',4,0,NULL),('c5ed25f8-5533-4d64-b60e-66483dc6acc6','ffe23d4b-7198-523a-b436-cacb0dde45ff','city','string',0,'','core',5,0,NULL),('c65f06da-bb4c-497e-ab83-2216e4aaf58e','2c0881ca-0e78-541a-9415-23d4967f1ca5','authors_raw','string',0,'','core',2,0,NULL),('c69a1788-35a2-43c2-a0d8-cb2708f5dd9e','b6697771-7e65-5743-bf76-b28682c20362','source','string',0,'','core',0,0,NULL),('c7fb46f6-361a-4850-bb0d-3710dd561e18','73458f60-7701-5d45-afd9-7adb82c615fb','source','string',0,'','core',0,0,NULL),('c902cd1f-e18b-4962-8f4d-4893ad9117ce','cdac3e3e-22d1-5e63-86d4-52e8baa67523','chain_code','string',0,'','core',0,0,NULL),('ca3cbea4-1e1c-490f-8b54-900e9b93df95','601f5f43-0da8-57d0-9009-eccbe3fb5ad0','target','string',0,'','core',1,0,NULL),('cd576392-37e7-4eb9-a0c9-a6d9740cf124','0ef6cd3b-ff8d-5c97-9b1f-5c26f81abfb9','target','string',0,'','core',1,0,NULL),('cd75e5d5-dc78-4156-bbe3-48bd7c673328','7b3c1d2e-0b6f-573d-8656-5227fe9fb4bf','target','string',0,'','core',1,0,NULL),('d22c4fb9-55bf-46c8-92c7-6ca2c556f6d7','93c39017-e78f-5e75-b87f-98be59a43e12','country_code','string',0,'','core',2,0,NULL),('d24d6abb-1f8d-48c3-9eb3-dbdf42b9bde0','097d97e5-1c41-5d05-b91e-f965814fc69f','source','string',0,'','core',0,0,NULL),('d2816a1d-47b9-4f92-9332-aaef8e3a005c','283aaf94-07a4-5bdb-af0a-d521b703790b','name_zh','string',0,'','core',0,0,NULL),('d3d49192-9310-4f13-a2db-2045bdd2773c','30ddf80e-08ab-52ee-a874-ee16bcd76ac7','target','string',0,'','core',1,0,NULL),('d5c7e88f-2599-4fc4-b093-bf57b96ffd87','42931488-6ba7-52d5-940d-c0a9b94904f0','source','string',0,'','core',0,0,NULL),('d6b97fb0-e726-4167-8c0b-c78ea97eb320','ffe23d4b-7198-523a-b436-cacb0dde45ff','name_zh','string',0,'','core',0,0,NULL),('d717fe9d-c6e4-466d-8f20-a2a3bdbcaf82','93c39017-e78f-5e75-b87f-98be59a43e12','application_date','string',0,'','core',3,0,NULL),('dc8df31a-167d-4084-94fc-4ab6a651185c','813d05a7-289f-5d16-80c6-2119df9102e9','source','string',0,'','core',0,0,NULL),('e05c9a94-ab21-46a7-a12f-c254561ad36d','e4f64b75-427f-5af5-8fa3-685dfcce1d11','node_type','string',0,'','core',1,0,NULL),('e0a422ef-2e08-417a-a74b-bf96f64a0cd0','09854c48-54fa-5ee7-9b90-4a70d13bf0b4','source','string',0,'','core',0,0,NULL),('e2e0fed3-6c32-4e5b-a12a-6cb0e4ca48b1','ffe23d4b-7198-523a-b436-cacb0dde45ff','org_category','string',0,'','core',3,0,NULL),('e2edfc0a-7b25-4cad-93cc-3a3e634e915d','381db037-df95-5c9a-82c4-310da83fa9c2','source','string',0,'','core',0,0,NULL),('e48273f1-7091-4461-ab10-3e462fa5c53f','02603b0f-a422-5fd0-8d3a-53be348e57ec','citation_count','string',0,'','dynamic',7,0,NULL),('e568595f-0297-4731-b7b6-e9ac1ddd8fc9','93c39017-e78f-5e75-b87f-98be59a43e12','anticipated_expiration','string',0,'','dynamic',8,0,NULL),('e660a44b-84f6-473a-9c77-547c13e8d738','2c0881ca-0e78-541a-9415-23d4967f1ca5','organization_raw','string',0,'','core',3,0,NULL),('e6736df4-239e-403c-8a87-b278daab20b7','93c39017-e78f-5e75-b87f-98be59a43e12','cpc_main','string',0,'','core',5,0,NULL),('e7443b06-fe1e-4ec0-a8d4-ecc359e89a94','93c39017-e78f-5e75-b87f-98be59a43e12','cited_by_nums','string',0,'','dynamic',7,0,NULL),('e7a56301-96cf-4ace-a6df-90c3e5346437','97bd0b0c-6ad8-51c5-9496-6fc0d6de8abc','source','string',0,'','core',0,0,NULL),('ea551797-30cb-45df-b0d4-8f60f61ca72a','532cc2ea-eecb-518b-99c8-88edc240e390','source','string',0,'','core',0,0,NULL),('ea797472-ff65-47e7-8677-cfa9ab1f81d1','bf904999-ee14-5755-bdc8-3b2bfd106ed8','target','string',0,'','core',1,0,NULL),('eba4ead8-382d-427d-a3ed-d78af680a2cf','2c0881ca-0e78-541a-9415-23d4967f1ca5','preparation_time','string',0,'','dynamic',7,0,NULL),('ec002515-ff02-4712-b6c1-11e888475b89','0ef6cd3b-ff8d-5c97-9b1f-5c26f81abfb9','source','string',0,'','core',0,0,NULL),('ee2128a2-4c69-453f-8172-8b0f9f90be93','532cc2ea-eecb-518b-99c8-88edc240e390','target','string',0,'','core',1,0,NULL),('ef22258b-03c5-48f6-b527-b9c8f26261ca','5390a50c-76dc-5c73-9539-7dd545ffa68d','source','string',0,'','core',0,0,NULL),('ef783049-9756-435b-91dc-70c911a29202','097d97e5-1c41-5d05-b91e-f965814fc69f','target','string',0,'','core',1,0,NULL),('f0364ab8-13fb-4bb1-8db2-bd80ad223199','1c33af51-947b-5c65-a242-b67c82a85781','target','string',0,'','core',1,0,NULL),('f0527bca-36ce-4e94-b953-a14b127bd3ec','0085cb12-f8da-558c-929f-f4a28b678a34','target','string',0,'','core',1,0,NULL),('f195e606-e067-43c4-ad7a-8b001084552e','93c39017-e78f-5e75-b87f-98be59a43e12','ipc_main','string',0,'','core',4,0,NULL),('f420c9e1-4353-46c8-b28c-74514077fdd3','dbaa2a42-66f7-5061-8175-c675ed08212b','standard_name','string',0,'','core',0,0,NULL),('f9f47341-0910-4129-90e1-7540b0229d86','0be976a5-5517-58dd-8155-ec80e942c308','source','string',0,'','core',0,0,NULL),('fa2aac6b-c2e6-46cb-876a-fd24be17fc77','67702440-021d-5db9-8a73-e13a5c11ce4f','event_heat','string',0,'','dynamic',6,0,NULL),('fa5b50e1-0c93-4b17-8be8-5c75f12bc9e4','0045f86f-6b91-5c17-8c8b-fd129b4737d6','source','string',0,'','core',0,0,NULL),('fcd6237d-7f0e-46f5-be89-689fbe63a842','2c0881ca-0e78-541a-9415-23d4967f1ca5','title_en','string',0,'','core',1,0,NULL),('fcd7dd70-ab68-4b1d-b568-e2b1ecc321ed','e4f64b75-427f-5af5-8fa3-685dfcce1d11','chain_score','string',0,'','dynamic',5,0,NULL);
/*!40000 ALTER TABLE `kg_schema_property` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kg_schema_script`
--

DROP TABLE IF EXISTS `kg_schema_script`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kg_schema_script` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `schema_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bucket` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `object_key` varchar(512) COLLATE utf8mb4_unicode_ci NOT NULL,
  `original_filename` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content_type` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size_bytes` bigint NOT NULL,
  `etag` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sha256` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uploaded_by` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `workflow_definition_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `workflow_function_name` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `captured_revision` int NOT NULL,
  `last_run_status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_run_error` varchar(1024) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `safety_summary` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `safety_issues` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `uploaded_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_kg_schema_script_schema` (`schema_id`),
  CONSTRAINT `kg_schema_script_ibfk_1` FOREIGN KEY (`schema_id`) REFERENCES `kg_schema_definition` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Schema Python 处理脚本 S3 对象元数据';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kg_schema_script`
--

LOCK TABLES `kg_schema_script` WRITE;
/*!40000 ALTER TABLE `kg_schema_script` DISABLE KEYS */;
/*!40000 ALTER TABLE `kg_schema_script` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `kg_schema_source`
--

DROP TABLE IF EXISTS `kg_schema_source`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `kg_schema_source` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `schema_id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `datasource_id` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `database_name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `table_name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pk_column` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `time_column` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `query_sql` text COLLATE utf8mb4_unicode_ci,
  `position` int NOT NULL,
  `created_at` datetime NOT NULL DEFAULT (now()),
  `updated_at` datetime NOT NULL DEFAULT (now()),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_kg_schema_source_table` (`schema_id`,`datasource_id`,`database_name`,`table_name`),
  KEY `idx_kg_schema_source_schema` (`schema_id`),
  CONSTRAINT `kg_schema_source_ibfk_1` FOREIGN KEY (`schema_id`) REFERENCES `kg_schema_definition` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Schema 来源表绑定';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `kg_schema_source`
--

LOCK TABLES `kg_schema_source` WRITE;
/*!40000 ALTER TABLE `kg_schema_source` DISABLE KEYS */;
/*!40000 ALTER TABLE `kg_schema_source` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reviews`
--

DROP TABLE IF EXISTS `reviews`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reviews` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `task_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `domain` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `updated_at` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_reviews_batch_id` (`batch_id`),
  KEY `ix_reviews_updated_at` (`updated_at`),
  KEY `ix_reviews_task_id` (`task_id`),
  KEY `ix_reviews_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reviews`
--

LOCK TABLES `reviews` WRITE;
/*!40000 ALTER TABLE `reviews` DISABLE KEYS */;
/*!40000 ALTER TABLE `reviews` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `key` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `source_updates`
--

DROP TABLE IF EXISTS `source_updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `source_updates` (
  `seq` int NOT NULL AUTO_INCREMENT,
  `domain` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `detected_at` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`seq`),
  KEY `ix_source_updates_domain` (`domain`),
  KEY `ix_source_updates_detected_at` (`detected_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `source_updates`
--

LOCK TABLES `source_updates` WRITE;
/*!40000 ALTER TABLE `source_updates` DISABLE KEYS */;
/*!40000 ALTER TABLE `source_updates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tasks`
--

DROP TABLE IF EXISTS `tasks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tasks` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `stage` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `task_status` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `domain` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `kind` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `processed_at` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_tasks_task_status` (`task_status`),
  KEY `ix_tasks_batch_id` (`batch_id`),
  KEY `ix_tasks_processed_at` (`processed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tasks`
--

LOCK TABLES `tasks` WRITE;
/*!40000 ALTER TABLE `tasks` DISABLE KEYS */;
/*!40000 ALTER TABLE `tasks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workflow_definitions`
--

DROP TABLE IF EXISTS `workflow_definitions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workflow_definitions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `workflow_type` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` int NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_workflow_definitions_category` (`category`),
  KEY `ix_workflow_definitions_workflow_type` (`workflow_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflow_definitions`
--

LOCK TABLES `workflow_definitions` WRITE;
/*!40000 ALTER TABLE `workflow_definitions` DISABLE KEYS */;
INSERT INTO `workflow_definitions` VALUES ('entity-project','kg.entity.project','entity',1,'{\"id\":\"entity-project\",\"name\":\"国内外项目实体工作流\",\"workflowType\":\"kg.entity.project\",\"category\":\"entity\",\"taskQueue\":\"tech-kg-workflows\",\"active\":true,\"sourceKind\":\"builtin\",\"steps\":[\"读取增量\",\"标准化\",\"抽取/对齐\",\"质量校验\",\"图谱写入\"],\"createdAt\":\"2026-09-04 03:46:25\"}');
/*!40000 ALTER TABLE `workflow_definitions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workflow_executions`
--

DROP TABLE IF EXISTS `workflow_executions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workflow_executions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `definition_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `workflow_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `run_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `started_at` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_workflow_executions_job_id` (`job_id`),
  KEY `ix_workflow_executions_workflow_id` (`workflow_id`),
  KEY `ix_workflow_executions_started_at` (`started_at`),
  KEY `ix_workflow_executions_status` (`status`),
  KEY `ix_workflow_executions_definition_id` (`definition_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflow_executions`
--

LOCK TABLES `workflow_executions` WRITE;
/*!40000 ALTER TABLE `workflow_executions` DISABLE KEYS */;
/*!40000 ALTER TABLE `workflow_executions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workflow_jobs`
--

DROP TABLE IF EXISTS `workflow_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workflow_jobs` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `task_type` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `definition_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(128) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL,
  `schedule_kind` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `cron` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_workflow_jobs_name` (`name`),
  KEY `ix_workflow_jobs_created_at` (`created_at`),
  KEY `ix_workflow_jobs_definition_id` (`definition_id`),
  KEY `ix_workflow_jobs_owner` (`owner`),
  KEY `ix_workflow_jobs_status` (`status`),
  KEY `ix_workflow_jobs_task_type` (`task_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflow_jobs`
--

LOCK TABLES `workflow_jobs` WRITE;
/*!40000 ALTER TABLE `workflow_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `workflow_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `workflow_schedules`
--

DROP TABLE IF EXISTS `workflow_schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `workflow_schedules` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `definition_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `active` int NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_workflow_schedules_definition_id` (`definition_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `workflow_schedules`
--

LOCK TABLES `workflow_schedules` WRITE;
/*!40000 ALTER TABLE `workflow_schedules` DISABLE KEYS */;
/*!40000 ALTER TABLE `workflow_schedules` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'techkg_control'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-15  9:04:47
